import { Link } from 'react-router-dom';

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-[#173E72]">Dashboard Monitoring BPR Bank bjb</h1>
      
      {/* Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-lg p-4 flex justify-between items-center border border-[#D1D9E6]">
          <div>
            <p className="text-xs text-[#4B4B4B] mb-1">Total BPR</p>
            <p className="font-bold text-lg text-[#1E1E1E]">1432</p>
          </div>
          <div className="bg-[#E3E0FF] rounded-lg p-3 flex items-center justify-center w-12 h-12">
            <i className="fas fa-users text-[#8B8BFF] text-xl"></i>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 flex justify-between items-center border border-[#D1D9E6]">
          <div>
            <p className="text-xs text-[#4B4B4B] mb-1">Total Provinsi</p>
            <p className="font-bold text-lg text-[#1E1E1E]">17</p>
          </div>
          <div className="bg-[#C9E9FF] rounded-lg p-3 flex items-center justify-center w-12 h-12">
            <i className="fas fa-home text-[#4FC3F7] text-xl"></i>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 flex justify-between items-center border border-[#D1D9E6]">
          <div>
            <p className="text-xs text-[#4B4B4B] mb-1">Total BPR Sehat</p>
            <p className="font-bold text-lg text-[#1E1E1E]">432</p>
          </div>
          <div className="bg-[#DFF7D9] rounded-lg p-3 flex items-center justify-center w-12 h-12">
            <i className="fas fa-cube text-[#7ED957] text-xl"></i>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 flex justify-between items-center border border-[#D1D9E6]">
          <div>
            <p className="text-xs text-[#4B4B4B] mb-1">Total BPR tidak sehat</p>
            <p className="font-bold text-lg text-[#1E1E1E]">1000</p>
          </div>
          <div className="bg-[#FFDBD0] rounded-lg p-3 flex items-center justify-center w-12 h-12">
            <i className="fas fa-history text-[#FF7F5A] text-xl"></i>
          </div>
        </div>
      </section>

      {/* Tables container */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        {/* Left table */}
        <div className="bg-white rounded-lg p-4 border border-[#D1D9E6] overflow-x-auto">
          <h2 className="font-semibold text-sm text-[#1E1E1E] mb-3">5 Data Aset BPR Tertinggi</h2>
          <table className="w-full text-xs text-[#1E1E1E]">
            <thead>
              <tr className="border-b border-[#D1D9E6]">
                <th className="py-3 text-left font-semibold pr-4 w-8">No</th>
                <th className="py-3 text-left font-semibold pr-4">Nama BPR</th>
                <th className="py-3 text-right font-semibold pr-4 w-36">Aset</th>
                <th className="py-3 text-left font-semibold">Kota/Kabupaten</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-[#D1D9E6]">
                <td className="py-3 pr-4 font-semibold">1</td>
                <td className="py-3 pr-4 max-w-[9rem]">PT BPR Shinta Putra Pengasih</td>
                <td className="py-3 pr-4 text-right font-semibold">6.904.036.421.000</td>
                <td className="py-3">Jawa Barat</td>
              </tr>
              <tr className="border-b border-[#D1D9E6]">
                <td className="py-3 pr-4 font-semibold">2</td>
                <td className="py-3 pr-4 max-w-[9rem]">PT. BPR Citra Ladon Rahardja</td>
                <td className="py-3 pr-4 text-right font-semibold">5.904.036.421.000</td>
                <td className="py-3">Jawa Barat</td>
              </tr>
              <tr className="border-b border-[#D1D9E6]">
                <td className="py-3 pr-4 font-semibold">3</td>
                <td className="py-3 pr-4 max-w-[9rem]">PT BPR Nusantara Bona Pasogit 24</td>
                <td className="py-3 pr-4 text-right font-semibold">4.904.036.421.000</td>
                <td className="py-3">Jawa Barat</td>
              </tr>
              <tr className="border-b border-[#D1D9E6]">
                <td className="py-3 pr-4 font-semibold">4</td>
                <td className="py-3 pr-4 max-w-[9rem]">PT BPR Shinta Putra Pengasih</td>
                <td className="py-3 pr-4 text-right font-semibold">3.904.036.421.000</td>
                <td className="py-3">Jawa Barat</td>
              </tr>
              <tr>
                <td className="py-3 pr-4 font-semibold">5</td>
                <td className="py-3 pr-4 max-w-[9rem]">PT BPR Jawa Timur</td>
                <td className="py-3 pr-4 text-right font-semibold">2.904.036.421.000</td>
                <td className="py-3">Jawa Timur</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Right table */}
        <div className="bg-white rounded-lg p-4 border border-[#D1D9E6] overflow-x-auto">
          <h2 className="font-semibold text-sm text-[#1E1E1E] mb-3">5 Data NPL BPR Terendah</h2>
          <table className="w-full text-xs text-[#1E1E1E]">
            <thead>
              <tr className="border-b border-[#D1D9E6]">
                <th className="py-3 text-left font-semibold pr-4 w-8">No</th>
                <th className="py-3 text-left font-semibold pr-4">Nama BPR</th>
                <th className="py-3 text-right font-semibold pr-4 w-20">NPL</th>
                <th className="py-3 text-left font-semibold">Kota/Kabupaten</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-[#D1D9E6]">
                <td className="py-3 pr-4 font-semibold">1</td>
                <td className="py-3 pr-4 max-w-[9rem]">PT BPR Shinta Putra Pengasih</td>
                <td className="py-3 pr-4 text-right font-semibold">0.1%</td>
                <td className="py-3">Jawa Barat</td>
              </tr>
              <tr className="border-b border-[#D1D9E6]">
                <td className="py-3 pr-4 font-semibold">2</td>
                <td className="py-3 pr-4 max-w-[9rem]">PT. BPR Citra Ladon Rahardja</td>
                <td className="py-3 pr-4 text-right font-semibold">1%</td>
                <td className="py-3">Jawa Barat</td>
              </tr>
              <tr className="border-b border-[#D1D9E6]">
                <td className="py-3 pr-4 font-semibold">3</td>
                <td className="py-3 pr-4 max-w-[9rem]">PT BPR Nusantara Bona Pasogit 24</td>
                <td className="py-3 pr-4 text-right font-semibold">2%</td>
                <td className="py-3">Jawa Barat</td>
              </tr>
              <tr className="border-b border-[#D1D9E6]">
                <td className="py-3 pr-4 font-semibold">4</td>
                <td className="py-3 pr-4 max-w-[9rem]">PT BPR Shinta Putra Pengasih</td>
                <td className="py-3 pr-4 text-right font-semibold">3%</td>
                <td className="py-3">Jawa Barat</td>
              </tr>
              <tr>
                <td className="py-3 pr-4 font-semibold">5</td>
                <td className="py-3 pr-4 max-w-[9rem]">PT BPR Jawa Timur</td>
                <td className="py-3 pr-4 text-right font-semibold">3.1%</td>
                <td className="py-3">Jawa Timur</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Risk Acceptance Criteria BPR */}
      <section className="mb-10">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-extrabold text-[#1E1E1E]">Risk Acceptance Criteria BPR</h2>
          <Link to="/ubah-rac" className="bg-[#1E3A70] text-white text-sm font-semibold rounded-md px-5 py-2 hover:bg-[#16325a] transition-colors">
            Ubah RAC
          </Link>
        </div>
        <div className="bg-white rounded-lg p-4 border border-[#D1D9E6] overflow-x-auto">
          <table className="w-full text-xs text-[#1E1E1E]">
            <thead>
              <tr className="border-b border-[#D1D9E6]">
                <th className="py-3 text-left font-semibold pr-4 w-20">NPL Nett {"<="}</th>
                <th className="py-3 text-left font-semibold pr-4 w-20">Laba Tahun {">="}</th>
                <th className="py-3 text-left font-semibold pr-4 w-28">Laba Bulan Berjalan {">="}</th>
                <th className="py-3 text-left font-semibold pr-4 w-20">KAP {"<"}</th>
                <th className="py-3 text-left font-semibold pr-4 w-24">KPMM/CAR {">="}</th>
                <th className="py-3 text-left font-semibold pr-4 w-28">Aset</th>
                <th className="py-3 text-left font-semibold pr-4 w-20">ROA {">="}</th>
                <th className="py-3 text-left font-semibold pr-4 w-20">BOPO {"<"}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="py-3 pr-4 font-normal">5,00%</td>
                <td className="py-3 pr-4 font-normal">1</td>
                <td className="py-3 pr-4 font-normal">1</td>
                <td className="py-3 pr-4 font-normal">10,35%</td>
                <td className="py-3 pr-4 font-normal">12,00%</td>
                <td className="py-3 pr-4 font-normal">10.000.000.000</td>
                <td className="py-3 pr-4 font-normal">0,10%</td>
                <td className="py-3 pr-4 font-normal">0,10%</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Fetch Data BPR */}
      <section className="mb-10">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-extrabold text-[#1E1E1E]">Fetch Data BPR</h2>
          <button className="bg-[#1E3A70] text-white text-sm font-semibold rounded-md px-5 py-2">
            Fetch Data
          </button>
        </div>
        <div className="bg-white rounded-lg p-6 border border-[#D1D9E6] overflow-x-auto">
          <table className="w-full text-xs text-[#1E1E1E]">
            <thead>
              <tr className="border-b border-[#D1D9E6]">
                <th className="py-3 text-left font-semibold pr-4 w-8">No</th>
                <th className="py-3 text-left font-semibold pr-4 w-28">Date</th>
                <th className="py-3 text-left font-semibold pr-4 w-24">Time</th>
                <th className="py-3 text-left font-semibold pr-4 w-36">Periode Laporan</th>
                <th className="py-3 text-left font-semibold pr-4 w-24">Status</th>
                <th className="py-3 text-left font-semibold pr-4">User</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-[#D1D9E6]">
                <td className="py-3 pr-4 font-semibold">1</td>
                <td className="py-3 pr-4">15-Jan-2025</td>
                <td className="py-3 pr-4">11:24:23</td>
                <td className="py-3 pr-4">Desember 2024</td>
                <td className="py-3 pr-4">Success</td>
                <td className="py-3 pr-4">M Alwi Nugraha</td>
              </tr>
              <tr className="border-b border-[#D1D9E6]">
                <td className="py-3 pr-4 font-semibold">2</td>
                <td className="py-3 pr-4">12-Okt-2024</td>
                <td className="py-3 pr-4">10:14:07</td>
                <td className="py-3 pr-4">September 2024</td>
                <td className="py-3 pr-4">Success</td>
                <td className="py-3 pr-4">M Alwi Nugraha</td>
              </tr>
              <tr className="border-b border-[#D1D9E6]">
                <td className="py-3 pr-4 font-semibold">3</td>
                <td className="py-3 pr-4">09-Jul-2024</td>
                <td className="py-3 pr-4">09:36:43</td>
                <td className="py-3 pr-4">Juni 2024</td>
                <td className="py-3 pr-4">Success</td>
                <td className="py-3 pr-4">M Alwi Nugraha</td>
              </tr>
              <tr className="border-b border-[#D1D9E6]">
                <td className="py-3 pr-4 font-semibold">4</td>
                <td className="py-3 pr-4">14-Apr-2024</td>
                <td className="py-3 pr-4">10:45:09</td>
                <td className="py-3 pr-4">Maret 2024</td>
                <td className="py-3 pr-4">Success</td>
                <td className="py-3 pr-4">M Alwi Nugraha</td>
              </tr>
              <tr>
                <td className="py-3 pr-4 font-semibold">5</td>
                <td className="py-3 pr-4">18-Feb-2024</td>
                <td className="py-3 pr-4">08:25:39</td>
                <td className="py-3 pr-4">Desember 2023</td>
                <td className="py-3 pr-4">Success</td>
                <td className="py-3 pr-4">M Alwi Nugraha</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Pagination */}
      <nav aria-label="Pagination" className="flex justify-center items-center space-x-2 py-4 bg-[#E9EDF5] rounded-md">
        <span className="text-xs text-[#4B4B4B]">Previous</span>
        <button aria-current="page" className="bg-[#1E3A70] text-white text-xs font-semibold rounded-md w-7 h-7 flex items-center justify-center">
          1
        </button>
        <button className="bg-[#D9D9D9] text-[#4B4B4B] text-xs font-semibold rounded-md w-7 h-7 flex items-center justify-center">
          2
        </button>
        <button className="bg-[#D9D9D9] text-[#4B4B4B] text-xs font-semibold rounded-md w-7 h-7 flex items-center justify-center">
          3
        </button>
        <button className="bg-[#D9D9D9] text-[#4B4B4B] text-xs font-semibold rounded-md w-7 h-7 flex items-center justify-center">
          4
        </button>
        <button className="bg-[#D9D9D9] text-[#4B4B4B] text-xs font-semibold rounded-md w-7 h-7 flex items-center justify-center">
          5
        </button>
        <span className="text-xs text-[#4B4B4B]">Next</span>
      </nav>
    </div>
  );
}
