import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const mockData = [
  {
    id: 1,
    sandi: '600001',
    nama: 'PT BPR Jawa Timur',
    aset: '2.904.036.421.000',
    labaDesember: '18.710.493.000',
    labaJuni: '11.132.072.000',
    npl: '3,39%',
    kpmm: '40,61%',
    roa: '0,87%',
    kap: '5,05%',
    bopo: '90,42%',
    result: 'Sehat',
    resultColor: 'text-green-600',
    indicatorColor: 'bg-green-600'
  },
  {
    id: 2,
    sandi: '600002',
    nama: 'PT BPR Shinta Putra Pengasih',
    aset: '14.257.999.000',
    labaDesember: '1.871.182.000',
    labaJuni: '710.372.000',
    npl: '30,91%',
    kpmm: '28,04%',
    roa: '-7,47%',
    kap: '26,22%',
    bopo: '141,89%',
    result: 'Sehat',
    resultColor: 'text-green-600',
    indicatorColor: 'bg-green-600'
  },
  {
    id: 3,
    sandi: '600003',
    nama: 'PT BPR Nusantara Bona Pasogit 24',
    aset: '14.257.999.000',
    labaDesember: '1.871.182.000',
    labaJuni: '710.372.000',
    npl: '30,91%',
    kpmm: '28,04%',
    roa: '-7,47%',
    kap: '26,22%',
    bopo: '141,89%',
    result: 'Tidak Sehat',
    resultColor: 'text-red-600',
    indicatorColor: 'bg-red-600'
  },
  {
    id: 4,
    sandi: '600004',
    nama: 'PT. BPR Citra Ladon Rahardja',
    aset: '14.257.999.000',
    labaDesember: '1.477.350.000',
    labaJuni: '710.372.000',
    npl: '30,91%',
    kpmm: '28,04%',
    roa: '1,64%',
    kap: '26,22%',
    bopo: '141,89%',
    result: 'Tidak Sehat',
    resultColor: 'text-red-600',
    indicatorColor: 'bg-red-600'
  },
  {
    id: 5,
    sandi: '600005',
    nama: 'PT BPR Shinta Putra Pengasih',
    aset: '14.257.999.000',
    labaDesember: '1.871.182.000',
    labaJuni: '710.372.000',
    npl: '30,91%',
    kpmm: '28,04%',
    roa: '-7,47%',
    kap: '26,22%',
    bopo: '141,89%',
    result: 'Sehat',
    resultColor: 'text-green-600',
    indicatorColor: 'bg-green-600'
  },
  {
    id: 6,
    sandi: '600006',
    nama: 'PT BPR Nusantara Bona Pasogit 24',
    aset: '14.257.999.000',
    labaDesember: '1.871.182.000',
    labaJuni: '710.372.000',
    npl: '30,91%',
    kpmm: '28,04%',
    roa: '-7,47%',
    kap: '26,22%',
    bopo: '141,89%',
    result: 'Tidak Sehat',
    resultColor: 'text-red-600',
    indicatorColor: 'bg-red-600'
  },
  {
    id: 7,
    sandi: '600007',
    nama: 'PT. BPR Citra Ladon Rahardja',
    aset: '14.257.999.000',
    labaDesember: '1.477.350.000',
    labaJuni: '710.372.000',
    npl: '30,91%',
    kpmm: '28,04%',
    roa: '1,64%',
    kap: '26,22%',
    bopo: '141,89%',
    result: 'Sehat',
    resultColor: 'text-green-600',
    indicatorColor: 'bg-green-600'
  },
  {
    id: 8,
    sandi: '600008',
    nama: 'PT BPR Shinta Putra Pengasih',
    aset: '14.257.999.000',
    labaDesember: '1.871.182.000',
    labaJuni: '710.372.000',
    npl: '30,91%',
    kpmm: '28,04%',
    roa: '-7,47%',
    kap: '26,22%',
    bopo: '141,89%',
    result: 'Tidak Sehat',
    resultColor: 'text-red-600',
    indicatorColor: 'bg-red-600'
  },
  {
    id: 9,
    sandi: '600009',
    nama: 'PT BPR Nusantara Bona Pasogit 24',
    aset: '14.257.999.000',
    labaDesember: '1.871.182.000',
    labaJuni: '710.372.000',
    npl: '30,91%',
    kpmm: '28,04%',
    roa: '-7,47%',
    kap: '26,22%',
    bopo: '141,89%',
    result: 'Tidak Sehat',
    resultColor: 'text-red-600',
    indicatorColor: 'bg-red-600'
  },
  {
    id: 10,
    sandi: '600010',
    nama: 'PT. BPR Citra Ladon Rahardja',
    aset: '14.257.999.000',
    labaDesember: '1.477.350.000',
    labaJuni: '710.372.000',
    npl: '30,91%',
    kpmm: '28,04%',
    roa: '1,64%',
    kap: '26,22%',
    bopo: '141,89%',
    result: 'Sehat',
    resultColor: 'text-green-600',
    indicatorColor: 'bg-green-600'
  }
];

export default function ProfilingBPRPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  const handleDetailClick = (sandi) => {
    navigate(`/detail-bpr/${sandi}`);
  };

  return (
    <section className="px-8 py-8 flex flex-col gap-6">
      <h1 className="font-extrabold text-xl text-[#1E1E2D]">
        Profiling BPR
      </h1>
      
      <form className="bg-white rounded-lg p-6 grid grid-cols-1 md:grid-cols-[auto_auto_auto_1fr] gap-y-4 gap-x-4 items-center">
        <label className="text-[13px] font-normal text-[#1E1E2D] col-span-1 md:col-span-1" htmlFor="periode">
          Periode Pelaporan
        </label>
        <select className="border border-[#D1D5DB] rounded-md py-2 px-3 text-[13px] text-[#1E1E2D] col-span-1 md:col-span-1" id="month" name="month">
          <option>September</option>
        </select>
        <select className="border border-[#D1D5DB] rounded-md py-2 px-3 text-[13px] text-[#1E1E2D] col-span-1 md:col-span-1" id="year" name="year">
          <option>2022</option>
        </select>
        <div></div>
        
        <label className="text-[13px] font-normal text-[#1E1E2D] col-span-1 md:col-span-1" htmlFor="provinsi">
          Provinsi
        </label>
        <select className="border border-[#D1D5DB] rounded-md py-2 px-3 text-[13px] text-[#1E1E2D] col-span-1 md:col-span-3" id="provinsi" name="provinsi">
          <option>Semua Provinsi</option>
        </select>
        
        <label className="text-[13px] font-normal text-[#1E1E2D] col-span-1 md:col-span-1" htmlFor="kota">
          Kota/Kabupaten
        </label>
        <select className="border border-[#D1D5DB] rounded-md py-2 px-3 text-[13px] text-[#1E1E2D] col-span-1 md:col-span-3" id="kota" name="kota">
          <option>Semua Kota</option>
        </select>
        
        <label className="text-[13px] font-normal text-[#1E1E2D] col-span-1 md:col-span-1" htmlFor="bank">
          Bank BPR
        </label>
        <select className="border border-[#D1D5DB] rounded-md py-2 px-3 text-[13px] text-[#1E1E2D] col-span-1 md:col-span-3" id="bank" name="bank">
          <option>Semua BPR</option>
        </select>
        
        <button className="bg-[#1E3A70] text-white rounded-md py-3 px-6 justify-self-end col-span-1 md:col-span-1 mt-2 md:mt-0" type="submit">
          Tampilkan
        </button>
      </form>
      
      <section className="bg-[#F3F5F9] rounded-lg p-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-3">
          <div className="flex items-center gap-2 text-[13px] text-[#1E1E2D]">
            <span>Show</span>
            <select className="bg-[#1E3A70] text-white rounded-md py-1 px-3 text-[13px] font-semibold">
              <option>10</option>
            </select>
            <span>entries</span>
          </div>
          <div className="w-full md:w-72">
            <input 
              className="w-full border border-[#D1D5DB] rounded-md py-2 px-3 text-[13px] text-[#1E1E2D]" 
              placeholder="Cari..." 
              type="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        <div className="overflow-x-auto rounded-lg border border-[#D1D5DB] bg-white">
          <table className="w-full text-[11px] text-[#1E1E2D] border-collapse">
            <thead className="bg-[#F9FAFB] text-[11px] font-semibold text-[#6B7280]">
              <tr>
                <th className="border-b border-[#E6E8EC] text-left py-2 px-3 w-[30px]">No</th>
                <th className="border-b border-[#E6E8EC] text-left py-2 px-3 w-[70px]">Sandi</th>
                <th className="border-b border-[#E6E8EC] text-left py-2 px-3 min-w-[140px]">Nama BPR</th>
                <th className="border-b border-[#E6E8EC] text-right py-2 px-3 w-[110px] cursor-pointer select-none">
                  Aset
                  <i className="fas fa-sort-up ml-1 text-[#9CA3AF]"></i>
                </th>
                <th className="border-b border-[#E6E8EC] text-right py-2 px-3 w-[110px] cursor-pointer select-none">
                  Laba Desember 21
                  <i className="fas fa-sort-up ml-1 text-[#9CA3AF]"></i>
                </th>
                <th className="border-b border-[#E6E8EC] text-right py-2 px-3 w-[110px] cursor-pointer select-none">
                  Laba Juni 2022
                  <i className="fas fa-sort-up ml-1 text-[#9CA3AF]"></i>
                </th>
                <th className="border-b border-[#E6E8EC] text-right py-2 px-3 w-[70px] cursor-pointer select-none">
                  NPL Nett
                  <i className="fas fa-sort-up ml-1 text-[#9CA3AF]"></i>
                </th>
                <th className="border-b border-[#E6E8EC] text-right py-2 px-3 w-[70px] cursor-pointer select-none">
                  KPMM
                  <i className="fas fa-sort-up ml-1 text-[#9CA3AF]"></i>
                </th>
                <th className="border-b border-[#E6E8EC] text-right py-2 px-3 w-[70px] cursor-pointer select-none">
                  ROA
                  <i className="fas fa-sort-up ml-1 text-[#9CA3AF]"></i>
                </th>
                <th className="border-b border-[#E6E8EC] text-right py-2 px-3 w-[70px] cursor-pointer select-none">
                  KAP
                  <i className="fas fa-sort-up ml-1 text-[#9CA3AF]"></i>
                </th>
                <th className="border-b border-[#E6E8EC] text-right py-2 px-3 w-[70px] cursor-pointer select-none">
                  BOPO
                  <i className="fas fa-sort-up ml-1 text-[#9CA3AF]"></i>
                </th>
                <th className="border-b border-[#E6E8EC] text-right py-2 px-3 w-[70px] cursor-pointer select-none">
                  Result
                  <i className="fas fa-sort-up ml-1 text-[#9CA3AF]"></i>
                </th>
                <th className="border-b border-[#E6E8EC] text-left py-2 px-3 w-[90px] min-w-[90px]">
                  Data Lainnya
                </th>
              </tr>
            </thead>
            <tbody className="text-[11px] font-normal text-[#1E1E2D]">
              {mockData.map((item) => (
                <tr key={item.id} className="border-t border-[#E6E8EC]">
                  <td className="py-2 px-3">{item.id}</td>
                  <td className="py-2 px-3 font-semibold">{item.sandi}</td>
                  <td className="py-2 px-3 max-w-[140px]">{item.nama}</td>
                  <td className="py-2 px-3 text-right">{item.aset}</td>
                  <td className={`py-2 px-3 text-right ${item.labaDesember.includes('-') ? 'text-[#D14343]' : ''}`}>
                    {item.labaDesember}
                  </td>
                  <td className={`py-2 px-3 text-right ${item.labaJuni.includes('-') ? 'text-[#D14343]' : ''}`}>
                    {item.labaJuni}
                  </td>
                  <td className="py-2 px-3 text-right">{item.npl}</td>
                  <td className="py-2 px-3 text-right">{item.kpmm}</td>
                  <td className={`py-2 px-3 text-right ${item.roa.includes('-') ? 'text-[#D14343]' : ''}`}>
                    {item.roa}
                  </td>
                  <td className="py-2 px-3 text-right">{item.kap}</td>
                  <td className="py-2 px-3 text-right">{item.bopo}</td>
                  <td className={`py-2 px-3 ${item.resultColor} flex items-center gap-1`}>
                    <span className={`result-indicator ${item.indicatorColor} w-2 h-2 rounded-full`}></span>
                    {item.result}
                  </td>
                  <td className="py-2 px-3">
                    <button 
                      className="bg-[#1E3A70] text-white text-[11px] font-semibold rounded px-3 py-1 hover:bg-[#16325a] transition-colors"
                      onClick={() => handleDetailClick(item.sandi)}
                    >
                      Detail
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <nav aria-label="Pagination" className="flex justify-center items-center gap-2 mt-6 text-[11px] text-[#6B7280]">
          <button className="px-2 py-1">Previous</button>
          <button aria-current="page" className="bg-[#1E3A70] text-white rounded px-3 py-1 font-semibold">1</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">2</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">3</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">4</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">5</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">6</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">7</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">8</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">9</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">10</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">11</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">12</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">13</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">14</button>
          <button className="px-3 py-1 rounded bg-[#F3F5F9] hover:bg-[#E6E8EC]">15</button>
          <button className="px-2 py-1">Next</button>
        </nav>
      </section>
    </section>
  );
}
