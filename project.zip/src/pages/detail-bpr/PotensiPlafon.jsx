export default function PotensiPlafonPage() {
  return (
    <div>
      <form className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 max-w-4xl mb-10">
        <div className="flex flex-col">
          <label className="font-semibold text-sm mb-1" htmlFor="totalPlafon">
            Total Plafon Kredit
          </label>
          <span className="text-xs text-gray-600 mb-2">
            *berdasarkan LDR
          </span>
          <input 
            className="bg-[#F0F0F5] rounded-md border border-gray-300 px-4 py-3 font-semibold text-base focus:outline-none" 
            id="totalPlafon" 
            readOnly 
            type="text" 
            value="Rp 150.000.000.000"
          />
        </div>
        <div className="flex flex-col">
          <label className="font-semibold text-sm mb-1" htmlFor="npl">
            NPL
          </label>
          <span className="text-xs text-gray-600 mb-2">
            *laporan keuangan BPR
          </span>
          <input 
            className="bg-[#F0F0F5] rounded-md border border-gray-300 px-4 py-3 font-semibold text-base focus:outline-none" 
            id="npl" 
            readOnly 
            type="text" 
            value="2%"
          />
        </div>
        <div className="flex flex-col">
          <label className="font-semibold text-sm mb-1" htmlFor="wair">
            WAIR
          </label>
          <span className="text-xs text-gray-600 mb-2">
            *data OJK
          </span>
          <input 
            className="bg-[#F0F0F5] rounded-md border border-gray-300 px-4 py-3 font-semibold text-base focus:outline-none" 
            id="wair" 
            readOnly 
            type="text" 
            value="10%"
          />
        </div>
        <div className="flex flex-col">
          <label className="font-semibold text-sm mb-1" htmlFor="yield">
            Yield
          </label>
          <span className="text-xs text-gray-600 mb-2">
            *berdasarkan nilai WAIR &amp; NPL
          </span>
          <input 
            className="bg-[#F0F0F5] rounded-md border border-gray-300 px-4 py-3 font-semibold text-base focus:outline-none" 
            id="yield" 
            readOnly 
            type="text" 
            value="9,8%"
          />
        </div>
        <div className="flex flex-col md:col-span-2 max-w-md">
          <label className="font-semibold text-sm mb-1" htmlFor="cof">
            COF
          </label>
          <span className="text-xs text-gray-600 mb-2">
            *laporan keuangan Bank bjb
          </span>
          <input 
            className="bg-[#F0F0F5] rounded-md border border-gray-300 px-4 py-3 font-semibold text-base focus:outline-none" 
            id="cof" 
            readOnly 
            type="text" 
            value="6%"
          />
        </div>
      </form>
      
      <p className="max-w-4xl mb-10 text-gray-700 text-sm leading-relaxed">
        Berdasarkan data proyek potensi keuntungan, penyaluran kredit kepada
        BPR Sehat menimbang dari hasil indikator keuangan melalui laporan
        keuangan masing-masing BPR Sehat, menghasilkan
        <strong>
          NIM
        </strong>
        dan menunjukan
        <strong>
          Potensi Keuntungan
        </strong>
        sebesar:
      </p>
      
      <div className="max-w-4xl flex flex-col md:flex-row gap-6">
        <div className="flex-1 bg-white rounded-xl p-6 flex items-center justify-between shadow-md">
          <div>
            <div className="text-xs text-gray-600 mb-1">
              NIM
            </div>
            <div className="font-extrabold text-xl">
              3,8%
            </div>
          </div>
          <div className="bg-[#E9FFCC] rounded-lg p-4 text-[#7FC241] flex items-center justify-center" style={{width:'48px', height:'48px'}}>
            <i className="fas fa-wallet text-lg"></i>
          </div>
        </div>
        <div className="flex-1 bg-white rounded-xl p-6 flex items-center justify-between shadow-md">
          <div>
            <div className="text-xs text-gray-600 mb-1">
              Total Potensi Keuntungan
            </div>
            <div className="font-extrabold text-xl">
              Rp 5.700.000.000
            </div>
          </div>
          <div className="bg-[#FFF3CC] rounded-lg p-4 text-[#F9D54C] flex items-center justify-center" style={{width:'48px', height:'48px'}}>
            <i className="fas fa-money-bill-alt text-lg"></i>
          </div>
        </div>
      </div>
    </div>
  );
}
