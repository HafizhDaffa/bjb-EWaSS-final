const mockData = {
  sandi: '60001',
  nama: 'PT BPR Jawa Timur',
  alamat: 'Jl Raya Solo No 30 Kab. Madiun',
  daerahTingkat: 'Kab. Madiun',
  telepon: '088804900049',
  email: 'info@bankmadiun.com',
  provinsi: 'Provinsi Jawa Timur',
  wilayahKerja: 'Kantor Regional 4 Jawa Timur'
};

export default function InformasiUmumPage() {
  return (
    <div className="p-6 text-sm text-gray-800 space-y-4">
      <div>
        <span className="font-semibold">
          Sandi
        </span>
        <br/>
        <span>
          {mockData.sandi}
        </span>
      </div>
      <div>
        <span className="font-semibold">
          Nama BPR
        </span>
        <br/>
        <span>
          {mockData.nama}
        </span>
      </div>
      <div>
        <span className="font-semibold">
          Alamat
        </span>
        <br/>
        <span>
          {mockData.alamat}
        </span>
      </div>
      <div>
        <span className="font-semibold">
          Daerah Tingkat II
        </span>
        <br/>
        <span>
          {mockData.daerahTingkat}
        </span>
      </div>
      <div>
        <span className="font-semibold">
          Nomor Telepon
        </span>
        <br/>
        <span>
          {mockData.telepon}
        </span>
      </div>
      <div>
        <span className="font-semibold">
          Email
        </span>
        <br/>
        <span>
          {mockData.email}
        </span>
      </div>
      <div>
        <span className="font-semibold">
          Provinsi
        </span>
        <br/>
        <span>
          {mockData.provinsi}
        </span>
      </div>
      <div>
        <span className="font-semibold">
          Wilayah Kerja
        </span>
        <br/>
        <span>
          {mockData.wilayahKerja}
        </span>
      </div>
    </div>
  );
}
