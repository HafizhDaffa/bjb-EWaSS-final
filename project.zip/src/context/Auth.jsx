import { createContext, useContext, useState } from 'react';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  // Set default user for development bypass
  const [user, setUser] = useState({ 
    id: 1, 
    email: 'dev@example.com',
    name: 'M Alwi Nugraha',
    role: 'Divisi Komersial'
  });
  const [isLoading, setIsLoading] = useState(false);

  const login = async (email, password) => {
    setIsLoading(true);
    try {
      // Bypass authentication for development
      const dummyUser = { 
        id: 1, 
        email: email || 'dev@example.com',
        name: 'M Alwi Nugraha',
        role: 'Divisi Komersial'
      };
      setUser(dummyUser);
      return { user: dummyUser, token: 'dummy-token' };
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (email, password) => {
    setIsLoading(true);
    try {
      // Bypass registration for development
      const dummyUser = { 
        id: 1, 
        email: email || 'dev@example.com',
        name: 'M Alwi Nugraha',
        role: 'Divisi Komersial'
      };
      setUser(dummyUser);
      return { user: dummyUser, token: 'dummy-token' };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('token');
  };

  const value = {
    user,
    login,
    register,
    logout,
    isAuthenticated: !!user,
    isLoading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export default AuthContext;
